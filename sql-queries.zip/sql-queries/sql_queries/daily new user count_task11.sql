SELECT
    DATE(registration_date) AS reg_day,
    COUNT(*) AS total_users
FROM Users
WHERE registration_date >= CURDATE() - INTERVAL 7 DAY
GROUP BY DATE(registration_date)
ORDER BY reg_day;